# Bailian (百炼) Free Quota & Billing Structure

## Token Types

Bailian has THREE separate token/credit systems that are NOT interchangeable:

### 1. Free Quota (免费额度)
- Per-model allocation: typically **1M tokens per model**
- Total: 165+ models × 1M = **165M+ free tokens**
- Expiry: typically 90 days from account activation
- Per-model, not pooled
- Status shown in 模型用量 → 免费额度 tab
- When exhausted: returns HTTP 403 `AllocationQuota.FreeTierOnly.`
- Has an "免费额度用完即停" toggle — when OFF, free quota exhaustion does NOT switch to pay-as-you-go; when ON, post-paid billing kicks in after free quota

### 2. Token Plan (订阅/Token Plan 团队版)
- Prepaid subscription (standard/advanced/premium)
- Uses Credits (not raw tokens)
- One per account max
- Pooled across all supported models
- Billing: monthly subscription
- Not currently active for this account

### 3. Pay-as-you-go (按量付费)
- Direct billing to account balance
- Charged when free quota exhausted AND "免费额度用完即停" is ON
- Charges are in CNY (¥)

## Billing Console
- Main page: `https://billing-cost.console.aliyun.com/home`
- Account balance and overdue status shown here
- Recharge: 费用 → 充值汇款
- Minimum recharge via Alipay: ¥1 (recommended ¥10)

## Usage Stats (用量统计)

The 模型用量 → 用量统计 tab shows real consumption:

**Example from June 2026:**
- 调用模型数: 6 models called
- 调用成功总次数: 55 calls
- Token总数: 2,280K tokens (2.28M)
- Среднее на запрос: 41K tokens

**Top called models:**
| Rank | Model | Calls | Has Free Quota? |
|------|-------|-------|-----------------|
| 1 | deepseek-v4-flash | 33 | ❌ NO — post-paid! |
| 2 | qwen3.7-max | 19 | ✅ (1M, 62% consumed = 380K left) |
| 3 | qwen3.6-plus | 3 | ✅ (1M, 1% consumed = 990K left) |

### qwen3.7-max Free Quota Status
**62% consumed** (剩379,790/共1,000,000) — the most heavily used free model. Will run out if usage continues at this rate.

## Models WITHOUT Free Quota (платные)

34 models total have **no free quota**. Using them incurs post-paid charges ($). These are mostly third-party models (DeepSeek, Kimi, MiniMax) that Bailian resells:

### Page 1 of 4 (10 models confirmed):
| Model Code | Notes |
|------------|-------|
| **deepseek-v4-flash** | ⚠️ Default model in Hermes — EACH CALL IS PAID |
| vanchin/deepseek-v4-pro | ⚠️ Paid |
| qwen-deep-research-2025-12-15 | Paid |
| qwen-deep-research | Paid |
| MiniMax/MiniMax-M3 | Paid |
| kimi/kimi-k2.6 | Paid |
| MiniMax/MiniMax-M2.7 | Paid |
| kimi/kimi-k2.5 | Paid |
| MiniMax/MiniMax-M2.5 | Paid |
| MiniMax/MiniMax-M2.1 | Paid |

### How to see the full list:
1. Navigate to 模型用量 → 免费额度 tab
2. Click "查看详情" on the **无免费额度模型** card (red, count=34)
3. Pagination: 4 pages total

### Safe alternatives (same capability, FREE):
| Instead of... | Use... | Reason |
|---------------|--------|--------|
| deepseek-v4-flash | qwen3.6-flash or qwen3.6-plus | Free quota 1M, fast, capable |
| deepseek-v4-pro | qwen3.7-max | Free quota 1M (380K remaining) |
| kimi-k2.6 | qwen3.7-plus | Free quota 1M (926K remaining) |

## 免费额度用完即停 Toggle

The "免费额度用完即停" toggle on the free quota page defaults to **OFF** (status: 未开启).

**Consequence when OFF:** When free quota is exhausted, API returns 403 `AllocationQuota.FreeTierOnly.` — service stops cleanly. NO post-paid charges.

**Consequence when ON:** When free quota is exhausted, billing switches to pay-as-you-go automatically. This is how the ¥0.21 debt happened.

**Recommendation:** Keep toggled OFF for all models unless you explicitly want post-paid overflow.

## Common Issues

**"部分功能使用受限 / 账号已欠费"**
- Account balance is negative (even -¥0.21 triggers this)
- Blocks ALL API access, including free quota
- Fix: top up → balance goes ≥ ¥0 → everything resumes immediately
- Free tokens are NOT lost — they're just blocked until balance is resolved

**165M tokens "disappeared" in one day**
- Likely not consumed — the user just noticed API stopped working
- Check 模型用量 → 免费额度 tab: `剩X/共1,000,000`
- If remaining == total, tokens were never used
- Problem is account balance (-¥0.21), not token expiry/consumption

## Navigation
- Console: `https://bailian.console.aliyun.com/cn-beijing?tab=model#/model-market`
- Sidebar navigation uses JS events, not `<a>` links — dispatch MouseEvent('click') via CDP
- Content loaded in iframe `free.aliyun.com/smarter-engine` — use CDP frame_id to interact
- Tab navigation (模型/应用/订阅/体验) uses parent-page URL hash, not iframe content
- Model usage: click "模型用量" in sidebar, then "免费额度" sub-tab
