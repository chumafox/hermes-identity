# HuggingFace Model Download Failure Patterns from China

## Discovery (June 2026)

huggingface.co is unreliably accessible from BOTH mainland China and Hong Kong.

- **Display Mac (HK location):** `curl https://huggingface.co` → 000 (connection timeout after 5s)
- **Pro (China mainland, via proxy):** `curl https://huggingface.co` → 000 (timeout)
- **hf-mirror.com:** `curl https://hf-mirror.com` → 200 in 0.66s (accessible from both)

## The CAS Bridge Problem

hf-mirror.com relays configuration/metadata files correctly, but large model weight files (`.safetensors`) are served via `cas-bridge.xethub.hf.co` — XetHub's content-addressable storage CDN. This CDN is also blocked/timed out from China:

```
Error while downloading from https://cas-bridge.xethub.hf.co/xet-bridge-us/...
HTTPSConnectionPool(host='cas-bridge.xethub.hf.co', port=443): Read timed out.
```

**Pattern:** Small files (config.json, tokenizer_config.json, vocab.json) download fine via hf-mirror.com. The moment it hits weight files (`model.safetensors`, `speech_tokenizer/model.safetensors`), the connection hangs.

## The Signed URL Retry Loop

`huggingface-cli download --resume-download` retries failed downloads with exponential backoff. However, the download URLs contain signed URLs with `X-Amz-Expires=3600` (1-hour expiry). 
When a download is slow enough that the URL expires (common from China at 50-100 KB/s for 150MB+ files):

1. First attempt: starts downloading, gets partial data, then times out
2. Resume attempt: `--resume-download` computes range header from partial file
3. Server checks signed URL → expired → returns 403
4. Client retries: fetches a NEW signed URL from HF API
5. HF API → connection timeout from China
6. Repeat from step 1

This creates a loop that never completes.

## What DOES Work (confirmed)

**Small files (<50MB):**
```bash
HF_ENDPOINT=https://hf-mirror.com huggingface-cli download \
  mlx-community/Qwen3-TTS-12Hz-0.6B-Base-bf16 \
  --local-dir ~/.cache/huggingface/hub/models--mlx-community--Qwen3-TTS-12Hz-0.6B-Base-bf16 \
  --resume-download
```
Configuration files (14.6KB each) → ok. Weight files (150MB+, 955MB total) → CAS bridge timeout.

**Larger files require:**
- ModelScope (modelscope.cn) for Qwen/Alibaba models (see china-networking SKILL.md)
- Download on a non-China machine and transfer over cable/SCP
- aria2c with the direct .safetensors URL may work better than huggingface-cli

## What Did NOT Work

| Method | Result |
|--------|--------|
| Direct `huggingface-cli download` from HK Mac | ConnectTimeout (huggingface.co blocked) |
| `HF_ENDPOINT=https://hf-mirror.com` from China Mac | LocalEntryNotFoundError (mirror doesn't re-serve) |
| `HF_ENDPOINT=https://hf-mirror.com` from HK Mac | Config files OK, weight files CAS bridge timeout |
| Direct `huggingface-cli download` from China Mac with proxy | Very slow (22s/file), partial progress (~36%), eventually ReadTimeout on CAS weight files |
| `unset http_proxy` + direct download | huggingface.co unreachable |
| aria2c / wget direct to cas-bridge.xethub.hf.co | Same CDN, same timeout |
| hf-mirror.com HEAD request for model.safetensors | 302 redirect to cas-bridge.xethub.hf.co signed URL |

## Details of Partial Progress (New, June 2026)

When downloading from a China Mac with active proxy (Shadowrocket NE via utun4 tunnel), `huggingface-cli download --resume-download` made partial progress:

- **mlx-community/Qwen3-TTS-12Hz-0.6B-Base-bf16**: 5/14 files complete (36%), 151MB of 955MB. The small files completed (~50MB: configs, tokenizer, vocab, merges). The CAS bridge weight files (speech_tokenizer/model.safetensors at 150MB) started downloading at ~50-100 KB/s but timed out repeatedly with signed URL expiry loop.

- **mlx-community/Qwen3-TTS-12Hz-0.6B-Base-4bit**: Same pattern. 5/14 files complete in 15 seconds, then stuck on CAS bridge weights. Dowloaded 461MB + 545MB partial files (1.3GB reported by du due to incomplete double-cache) before all retries exhausted.

**Key insight:** The bf16 model consists of a SINGLE `model.safetensors` file (~900MB) — no shards. This means there's no incremental progress: even if 90% downloads, a single read timeout resets the entire file when the signed URL expires. Sharded models (multiple model-00001-of-XXXX.safetensors files) would be more resilient to China's connection instability.

**Confirmed:** Both bf16 AND 4bit quantized versions of this MLX model are stored on XetHub (CAS bridge). No way to bypass this CDN for MLX-community models stored on XetHub.

The huggingface_hub API `list_repo_files()` also fails with 401 (`Repository Not Found`) for repos that DO exist — the API may silently enforce auth for certain metadata operations even on public repos.

## Model Size Reference

`mlx-community/Qwen3-TTS-12Hz-0.6B-Base-bf16`:
- Total: ~955 MB
- Config files: ~50 MB (vocab, merges, configs — all download OK)
- Weight files: ~900 MB (single `model.safetensors` + speech_tokenizer/model.safetensors — both on CAS bridge)

`mlx-community/Qwen3-TTS-12Hz-0.6B-Base-4bit`:
- Total: ~400 MB (smaller weights due to 4-bit quantization)
- Still behind same CAS bridge — quantized models also on XetHub storage

**General rule:** Model repos that use XetHub (identified by `206_58350f2e2c3a1c0e9d6a408f87b7b2e047826ca0b2790d60b84fbb93aa32ac87_e77d010c1790e4355fba80508387f3c72cde59d1` hash in blobs directory) are unusable from China. Check blobs directory to confirm before attempting download.

## Alternative: Convert from PyTorch Locally

If the PyTorch version of the model is cached (via HF hub or ModelScope), convert it to MLX format locally:

```bash
# 1. Download PyTorch version from ModelScope (China-accessible)
pip install modelscope
python3 -c "
from modelscope import snapshot_download
snapshot_download('Qwen/Qwen3-TTS-12Hz-0.6B-Base')
"

# 2. Convert to MLX using mlx-audio
# mlx_audio/convert.py exists but may not support Qwen3 directly.
# Alternative: manual weight loading with mlx core.
```
