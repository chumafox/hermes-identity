# Alibaba Cloud Bailian Console Navigation (CDP + Iframe)

## Overview

Bailian console (https://bailian.console.aliyun.com) is an SPA that loads ALL content in a cross-origin iframe from `free.aliyun.com/smarter-engine`. The parent page's a11y tree shows only "2 iframes" — standard Hermes browser tools (snapshot, click) can't see the actual content.

## Prerequisites

- Brave running with CDP (`--remote-debugging-port=9222`)
- In China: Brave must bypass proxy for aliyun domains or it loads slowly:
  ```
  --proxy-bypass-list='*.aliyun.com,*.alicdn.com,*.alibaba.com,*.aliyuncs.com'
  ```
- Logged in as main account (user sees "nick7870550749" / "主账号" in the iframe)

## Frame Discovery

Always get the frame_id before attempting iframe extraction:

```python
# After browser_navigate, check browser_snapshot output's frame_tree
# The content iframe has url starting with:
#   "https://free.aliyun.com/smarter-engine?at_iframe=1"
#
# Multiple copies may exist — pick any one, they're all the same content.

# Example frame_id: "ED40CC04A20795855C21B7CE4423DCFD"
```

## Multi-Tab CDP Approach (target_id)

When the iframe frame_id approach is unreliable (frame_tree shows `top: null` or stale children), use the multi-tab approach:

```python
# 1. List all open browser tabs
browser_cdp(method="Target.getTargets", params={})

# 2. Find the Bailian console tab by URL pattern
# Target list shows multiple pages — pick the right one by URL:
#   url: "https://bailian.console.aliyun.com/cn-beijing?tab=plan#/..."
#   url: "https://bailian.console.aliyun.com/cn-beijing?tab=model#/..."

# 3. Activate the target
browser_cdp(method="Target.activateTarget", params={"targetId": "TARGET_ID"})

# 4. Read page content from that specific target
browser_cdp(method="Runtime.evaluate", target_id="TARGET_ID",
  params={"expression": "document.body.innerText.substring(0,5000)", "returnByValue": true})

# 5. Click elements via JS in that target
browser_cdp(method="Runtime.evaluate", target_id="TARGET_ID",
  params={"expression": "el.dispatchEvent(new MouseEvent('click', {bubbles:true,cancelable:true}))", "returnByValue": true})
```

**Key difference:** `target_id` targets a full page tab, while `frame_id` targets a specific iframe within a page. Use `target_id` when the Bailian page opens in its own tab.

## Navigation Patterns

### Top Navigation Tabs

The top bar tabs (模型, 应用, 订阅, 体验, 文档, API 参考) change the `?tab=` query parameter:

| Tab | URL |
|-----|-----|
| 模型 (Model) | `?tab=model#/model-market` |
| 应用 (App) | `?tab=app` |
| 订阅 (Subscribe/Token Plan) | `?tab=subscribe` or `?tab=plan#/efm/subscription/overview` |
| 体验 (Experience) | `?tab=experience` |

**Clicking tabs inside the iframe:**
```javascript
var span = [...document.querySelectorAll('span')].filter(s=>s.textContent.trim()==='订阅')[0];
span.parentElement.dispatchEvent(new MouseEvent('click', {bubbles:true, cancelable:true}));
```

### Sidebar Navigation (左側メニュー)

Sidebar items inside the iframe are SPAN elements with specific icons. They DON'T change the parent URL — content appears in the right panel.

**Click sidebar item by text:**
```javascript
var span = [...document.querySelectorAll('span')].filter(s=>s.textContent.trim()==='模型用量')[0];
span.parentElement.dispatchEvent(new MouseEvent('click', {bubbles:true, cancelable:true}));
```

**Common sidebar items:**
| Item | English | Shows |
|------|---------|-------|
| 模型用量 | Model Usage | Token consumption charts + Free Quota tab |
| 限流提额 | Rate Limit/Quota | Rate limit increase requests |
| 费用概览 | Cost Overview | Billing summary (redirects to billing-cost console) |
| 我的订阅 | My Subscriptions | Token Plan subscription list |

### Cost Overview (费用概览)

Clicking "费用概览" navigates to `#/costing-balance/overview`. Key data:
- **总消费金额 (Total spend)**: current month in ¥
- **账期月份 (Billing period)**: defaults to current month
- **订阅购买费用 (Subscription fees)**: token plan costs
- **账单费用 (Bill costs)**: pay-as-you-go usage
- **费用告警 (Cost alert)**: configurable

## Free Quota (免费额度) Investigation

"165M tokens" is NOT a single token plan — it's 165 models × 1M free tokens each.

### Navigation to Free Quota Page

From `?tab=model#/model-market`, click **模型用量** sidebar, then select **免费额度** tab:

```javascript
// Step 1: Click "模型用量" sidebar
var span = [...document.querySelectorAll('span')].filter(s=>s.textContent.trim()==='模型用量')[0];
span.parentElement.dispatchEvent(new MouseEvent('click', {bubbles:true, cancelable:true}));

// Step 2: Read the free quota overview
```

### Free Quota Page Layout

```
免费额度 (Free Quota) | 用量统计 (Usage Stats) | 使用指南

免费额度使用概览:
  165  模型总数
  132  额度充沛
  33   无免费额度模型

免费额度即将用尽TOP3模型:
  0%  qwen-math-turbo      剩1,000,000/共1,000,000  过期: 2026/09/04
  0%  qwen3.7-plus         剩1,000,000/共1,000,000  过期: 2026/09/04
```

### Key Insights

- **`剩1,000,000/共1,000,000`** = ALL tokens still available (none consumed)
- **Same expiry date** for all models (e.g. 2026/09/04)
- **免费额度用完即停**: toggle for "stop when free quota exhausted" — default OFF (未开启)
- **Postpaid overflow**: if toggle OFF and quota exhausted → pay-as-you-go billing
- All models share the same 1M quota, not a shared pool

### Common Free Quota Scenarios

| Situation | Free Quota Page | Bill | Fix |
|-----------|----------------|------|-----|
| Free quota untouched, postpaid used | 剩1,000,000/共1,000,000 | ¥ -0.XX 欠费 | Top up balance |
| Free quota consumed | 剩0/共1,000,000 | ¥ XX.XX | Wait for reset or buy plan |

### Reading Free Quota Data via CDP

```python
browser_cdp(frame_id="FRAME_ID", method="Runtime.evaluate",
  params={"expression": "document.body.innerText.substring(0,5000)", "returnByValue": true})

# List all model quotas:
browser_cdp(target_id="TARGET", method="Runtime.evaluate",
  params={"expression": "[...document.querySelectorAll('tr')].map(tr=>tr.innerText.trim()).filter(t=>t.includes('剩')).join('\\n')", "returnByValue": true})
```

## Token Plan Subscription

### URL Patterns

| Tab | URL Pattern | Purpose |
|-----|-------------|---------|
| Token Plan Overview | `?tab=plan#/efm/subscription/overview` | Shows if subscribed |
| My Subscriptions | sidebar → 我的订阅 | Lists active subscriptions |
| Model Market | `?tab=model#/model-market` | Model listings |

### Checking Status

```javascript
// From Token Plan page, click "我的订阅" sidebar
var span = [...document.querySelectorAll('span')].filter(s=>s.textContent.trim()==='我的订阅')[0];
span.parentElement.click();
```

**Key texts:**
- **"您还未订阅 Token Plan"** — never had Token Plan
- **"7天内到期 0, 15天内到期 0"** — no active subscriptions
- **"当前暂未订阅 Token Plan团队版"** — no team subscription active

## Quota Investigation Workflow

When investigating why Bailian API stopped working:

1. **Check model-market page** — warning icon "部分功能使用受限" = account has an issue
2. **Check billing-cost console** (`https://billing-cost.console.aliyun.com/home`) — "账户可用额度" (balance)
3. **If balance negative** with "已欠费" — account overdue, services suspended
4. **Check 订阅 tab** — is Token Plan active?
5. **Check 模型用量 → 免费额度** — are free quotas still available?
6. **Check cost overview** — billing breakdown

### Common Scenarios

| Balance | Subscriptions | Free Quota | API Status | What Happened |
|---------|--------------|------------|------------|---------------|
| -¥0.21 | None | 1M each, intact (165 models) | Blocked | Free plan → postpaid overflow (¥0.21) → frozen |
| ¥0+ | Active | N/A | Working | Token Plan active |
| -¥X.XX | Active | Used up | Blocked | Postpaid debt from overflow |

### Recovery Steps

1. **Top up balance** (even ¥1) — clears 欠费 status
2. **Reactivate free quota** — toggle "免费额度用完即停" ON to prevent future overflow
3. **Buy Token Plan** — if free quota insufficient
4. **Or use pay-as-you-go** — after topping up, API works on per-token billing
