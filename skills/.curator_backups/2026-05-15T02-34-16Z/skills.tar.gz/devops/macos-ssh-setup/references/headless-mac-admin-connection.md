# Headless Mac Admin Connection

**Updated: 2026-05-11**

## Machine
- Model: MacBook Pro 16" 2021 (MacBookPro18,1)
- Chip: Apple M1 Pro (10-core: 8p + 2e)
- RAM: 32 GB
- macOS: 14.8.5 (Sonoma)
- Serial: JQV7HGFT75

## Connection Details
- **Username:** `admin`
- **Password:** `0000` (sudo)
- **WiFi IP:** `192.168.103.173` (SJYH network)
- **Type-C IP:** `169.254.227.249` (en5/en7, link-local)
- **SSH Key:** `~/.ssh/id_ed25519_hermes` (no passphrase)
- **Public key:** `ssh-ed25519 AAAAC3NzaC1lZDI1NTE5AAAAIIPMsqZjWvBmV2iU9br48V/GwyVOsBuBaHXNJYmOJX9D hermes-agent`

## Installed Software

### Essential Tools
- Command Line Tools (from screen Mac, macOS 14)
- Python 3.9.6 (system, via CLT)
- Node.js v22.16.0 + npm 10.9.2
- Git 2.39.5

### Hermes Agent
- Path: `~/.hermes/hermes-agent/`
- Version: v0.13.0
- CLI: `/Users/admin/bin/hermes` or `~/.local/bin/hermes` (symlink)
- Config: `~/.hermes/config.yaml` (copied from screen Mac)
- Env: `~/.hermes/.env` (KIMI_API_KEY, DEEPSEEK_API_KEY)

### Provider Configuration
- **Primary:** deepseek / deepseek-chat
- **Fallback:** none (was openrouter, removed)
- Agent config: `api_max_retries: 1`, `credential_pool_strategies.kimi-coding.backoff_seconds: 7200`

### LM Studio
- Path: `/Applications/LM Studio.app/`
- CLI: `/usr/local/bin/lms`
- Local model: `gemma-4-e4b-it-mlx` (8.97 GB, MLX backend)
- API: localhost:1234
- LM Studio provider in Hermes: `providers.lmstudio` (base_url: localhost:1234, api_key: lm-studio)
- **Note:** Gemma-4 context window is only 4096 tokens — below Hermes minimum 64000. Use for simple queries or as fallback.

### Ollama
- Version: 0.22.0
- Path: `/Applications/Ollama.app/`
- CLI: `/usr/local/bin/ollama` (symlink)
- No models downloaded yet

## Networking
- WiFi: SJYH network, unstable (33% packet loss, ~400ms ping to 8.8.8.8)
- Type-C: direct connection to screen Mac (jenyanovak), ~37 MB/s transfer speed
- Chinese firewall restrictions apply — use Bing/Baidu/Gitee/ModelScope for search

## Known Issues
- `sshpass` does NOT work on macOS — use `expect` with `spawn ssh -tt`
- ACLs on `/Users/admin` broke SSH key auth — fixed with `sudo chmod -N /Users/admin`
- No Xcode.app, only Command Line Tools
- `timeout` command unavailable (macOS) — use `gtimeout` or `perl -e 'alarm...'`
