---
name: hermes-self-maintenance
description: Поддержка identity-файлов (AGENTS.md, soul.md, memory), git-бэкап, cron-синхронизация
tags: [identity, git, backup, cron, auto-sync]
related_skills: [udemy-lecture-downloader]
---

# Hermes Self-Maintenance

Поддерживает identity-файлы агента в актуальном состоянии и синхронизирует их с GitHub,
чтобы при переустановке Hermes на другом железе не пришлось переучивать агента.

## Файлы

Все в `~/hermes-identity/` (git-репозиторий):

| Файл | Содержание |
|------|-----------|
| `AGENTS.md` | Копия `~/.hermes/AGENTS.md` — стиль, LLM-модели, принципы |
| `soul.md` | Суть агента: ценности, ключевые правила, окружение |
| `memory-backup.md` | Слепок памяти: пользователь, железо, сеть, проекты, провайдеры |
| `hermes-backlog.md` | Полка задач (ссылки на будущие проекты) |
| `.gitignore` | Игнор .env, .log, .DS_Store |
| `skills/` | Копии всех созданных навыков (SKILL.md + references) |

## Когда обновлять

1. **Новый skill создан** — скопировать в `~/hermes-identity/skills/<name>/`
2. **Память (memory) обновилась** — обновить `memory-backup.md`
3. **Изменился стиль/принципы** — обновить `AGENTS.md` и `soul.md`
4. **Новое железо/сеть/провайдер** — добавить в `memory-backup.md`
5. **Пользователь сказал "создай скрипт / автоматизацию"** — сохранить как skill + скопировать
6. **Новый крутой метод/подход найден** — задокументировать в memory-backup.md
7. **По прямой команде пользователя** — полный sync

## Git-команды

```bash
cd ~/hermes-identity
cp ~/.hermes/AGENTS.md .
git add -A
git commit -m "auto-update $(date +%Y-%m-%d)"
git push 2>&1 || echo "push failed (no remote?)"
```

## GitHub Remote Setup

Когда пользователь создаст репозиторий:

```bash
cd ~/hermes-identity
git remote add origin git@github.com:{USER}/{REPO}.git
git branch -M main
git push -u origin main
```

## Cron-задача

Уже создана:

```bash
hermes cron list  # найти identity-sync
```

Расписание: каждый день в 4:00 утра.
Обновляет файлы, коммитит и пушит.

Если remote не добавлен — push будет падать с ошибкой, но cron
не сломается (обёрнуто в `|| echo "push failed (no remote?)"`).

## memory-backup.md — структура

Ключевые разделы:
- User Profile (имя, логин, iMessage, ОС, локация, стиль общения)
- Projects & Interests
- Hardware Setup (два Mac: экранный + безголовый)
- Network Config (Thunderbolt, Type-C, интернет через iPhone)
- Software (на обоих Mac)
- LLM Providers & Roles (DeepSeek, Kimi, Claude)
- Known Tool Quirks
- Skills Created (список)
- Текущие проекты (например, Udemy курс)

## Правило автоматизации

**Пользователь требует:** рутинные/повторяющиеся задачи НЕ делать руками.
Сразу создавать скрипт или skill. Это экономит токены и время.
Сигнал: пользователь сказал "создай скрипт" или сделал однотипное действие дважды.

## References

- `references/identity-file-contents.md` — актуальное содержимое AGENTS.md и soul.md
- `templates/cron-setup.md` — как настроить cron-задачу в Hermes
