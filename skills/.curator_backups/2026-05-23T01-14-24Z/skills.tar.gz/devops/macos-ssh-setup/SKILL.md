---
name: macos-ssh-setup
description: Configure SSH access to headless or remote macOS machines, including link-local networking, key-based auth, and macOS ACL pitfalls.
category: devops
tags: [macos, ssh, headless, remote-access, expect, acl, link-local, troubleshooting]
---

# macOS SSH Setup

## When to Use
- Setting up SSH to a headless Mac (no display) over USB-C/Thunderbolt link-local (169.254.*)
- Connecting to a remote Mac over WiFi/LAN
- Troubleshooting "Permission denied (publickey)" on macOS despite correct keys and permissions

## Prerequisites
- Source machine with `ssh` and `expect` installed
- Target Mac: Remote Login enabled (`System Settings > Sharing > Remote Login`, or `sudo systemsetup -setremotelogin on`)

## Step-by-Step

### 1. Identify target IP
On the target Mac (via Screen Sharing, physical access, or another method):
```bash
ifconfig | grep "inet " | grep -v 127.0.0.1
```
A link-local address (`169.254.*`) indicates direct cable connection (USB-C/Thunderbolt).

### 2. Connectivity check
```bash
ping -c 2 <target_ip>
nc -z -w 3 <target_ip> 22
```

### 3. Key-based auth setup

**⚠️ Do NOT use `sshpass` on macOS.** It frequently hangs or silently fails on password prompts. Always use `expect` with `-tt` (pseudo-tty) for interactive sessions.

Generate a key **without passphrase** for automation. A local key with passphrase causes the macOS ssh client to prompt for it *before* attempting server authentication, breaking `sshpass` and confusing expect scripts.
```bash
ssh-keygen -t ed25519 -N "" -f ~/.ssh/id_ed25519_hermes -C "identifier"
```

Add the public key to the target using expect:
```bash
cat > /tmp/ssh_copy.exp << 'EOF'
#!/usr/bin/expect -f
set timeout 20
spawn ssh -tt -F /dev/null -o StrictHostKeyChecking=no admin@<target_ip>
expect {
    -re "Password:|password:" { send "PASSWORD\r"; exp_continue }
    "% " { }
    "$ " { }
}
sleep 1
send "mkdir -p ~/.ssh; chmod 700 ~/.ssh\r"
expect "% "
send "echo 'PUBKEY_CONTENTS' > ~/.ssh/authorized_keys; chmod 600 ~/.ssh/authorized_keys\r"
expect "% "
send "exit\r"
expect eof
EOF
chmod +x /tmp/ssh_copy.exp
```

### 4. ACL Pitfall on macOS
macOS applies ACLs to user home directories that can block `sshd` from reading `~/.ssh/authorized_keys` even when Unix permissions look correct.

**Symptom:** Correct key in `authorized_keys`, correct `chmod 600`, but still `Permission denied (publickey)`.

Check for ACL with `ls -le`:
```bash
ls -le /Users/<username>
```
If you see `+` after permissions and ACL entries (`0: group:everyone deny ...`), remove them:
```bash
sudo chmod -N /Users/<username>
```

After fix, verify `ls -le` no longer shows ACL entries on the home directory.

### 5. Install GUI apps on headless macOS
Headless Macs (no display) can still run applications copied from `.dmg` installers. Mount the DMG, copy `.app` to `/Applications/`, then symlink any internal CLI binaries (often found in `MyApp.app/Contents/Resources/app/.webpack/` or `MacOS/`) into `/usr/local/bin`.

Critical: for non-interactive SSH sessions, export PATH in `~/.zshenv` (not just `.zshrc`), as macOS zsh skips `.zshrc` for non-interactive shells:
```bash
echo 'export PATH="/usr/local/bin:$PATH"' >> ~/.zshenv
```

See detailed walkthrough in `references/lm-studio-headless-deployment.md`.

### Type-C / USB-C Direct Link — Static IP Setup

When two Macs are connected by a USB-C cable (not Thunderbolt), macOS assigns link-local (`169.254.x.x`) IPs that change on every reconnect. For stable SSH, assign static IPs.

**On both Macs, identify the Type-C interface:**

```bash
# After connecting the cable, find the interface with a 169.254.x.x IP
ifconfig | grep -B1 "inet 169.254" | grep -E "^[a-z]|inet "
# Note which interface (enX) has the Type-C link (look for the one NOT being bridge0 or en0)
```

**On the target (headless) Mac — create a network service:**

```bash
# 1. Create a service for the interface (replace enX with actual interface)
sudo networksetup -createnetworkservice "USB-C Link" enX

# 2. Assign static IP (192.168.3.0/24 doesn't conflict with Thunderbolt 192.168.2.x)
sudo networksetup -setmanual "USB-C Link" 192.168.3.2 255.255.255.0 192.168.3.1

# 3. Cycle interface to apply
sudo ifconfig enX down && sleep 1 && sudo ifconfig enX up
```

**On the source Mac — if networksetup doesn't recognize the interface:** some Macs have interfaces (`en7`) that aren't registered as hardware ports in `networksetup -listallhardwareports`. Use `ifconfig` directly:

```bash
# Assign IP directly (NOT persistent across reboots)
sudo ifconfig enY inet 192.168.3.1 netmask 255.255.255.0

# Verify
ping -c 2 192.168.3.2
ssh -i ~/.ssh/key admin@192.168.3.2 hostname
```

**Persistence:** The `networksetup` service survives reboot. The `ifconfig` method does NOT — you'll need a launchd plist (see below) or re-run on next Type-C connection.

### Launchd Plist — Persistent Static IP for Unregistered Interfaces

When `networksetup -createnetworkservice` fails with `"enX is not a valid hardware port name"`, the interface cannot be registered as a service. Use a launchd daemon to assign the static IP at boot instead:

```bash
# Create the plist (replace enX and IPs as needed)
sudo tee /Library/LaunchDaemons/com.local.usb-c-ip.plist > /dev/null << 'EOF'
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
    <key>Label</key>
    <string>com.local.usb-c-ip</string>
    <key>ProgramArguments</key>
    <array>
        <string>/sbin/ifconfig</string>
        <string>enX</string>
        <string>inet</string>
        <string>192.168.3.1</string>
        <string>netmask</string>
        <string>255.255.255.0</string>
    </array>
    <key>RunAtLoad</key>
    <true/>
    <key>KeepAlive</key>
    <false/>
    <key>StandardErrorPath</key>
    <string>/dev/null</string>
    <key>StandardOutPath</key>
    <string>/dev/null</string>
</dict>
</plist>
EOF

# Load and verify
sudo launchctl load -w /Library/LaunchDaemons/com.local.usb-c-ip.plist
sudo launchctl list | grep usb-c  # should show "-	0	com.local.usb-c-ip"
```

**Pitfall:** The enX interface number may change if other hardware is connected/disconnected (iPhone USB tethering, additional adapters). On the test machine (MacBook Pro M1 Pro), `en7` was stable for Type-C direct Mac-to-Mac connections. Verify with `ifconfig enX 2>/dev/null | grep "inet "` — if no IP appears after boot, the interface number shifted.

### Static IP Scheme Recommendation

| Connection | Subnet | Headless IP | Display IP |
|---|---|---|---|
| Thunderbolt Bridge | 192.168.2.0/24 | 192.168.2.2 | 192.168.2.1 |
| USB-C / Type-C | 192.168.3.0/24 | 192.168.3.2 | 192.168.3.1 |
| iPhone USB (tethering) | DHCP (172.20.10.x) | — | — |

### Thunderbolt Bridge: Cable type matters
Thunderbolt Bridge between two Macs requires a **Thunderbolt-compatible cable** (passive or active).
A standard USB-C cable (USB 2.0/3.x) plugged into a Thunderbolt port will:
- Charge
- MAY negotiate USB 2.0/3.x data (but not Thunderbolt)
- NOT create an IP-based bridge (no `bridge0` interface, no 192.168.2.x IPs)

**Verify:** `ifconfig bridge0 2>/dev/null | grep "inet "` — if empty, the cable isn't Thunderbolt-capable or isn't detected.

Once active: both Macs get link-local IPs automatically (e.g. 192.168.2.1 and 192.168.2.2).
Connect via `ssh user@192.168.2.2` or `ssh user@HOSTNAME.local`.

### Offline Installation of Python Applications

When the target Mac has no internet (or restricted/censored internet), bundle the entire runtime on the source machine and transfer via SCP/HTTP over the direct cable.

**Bundle structure:**
```
hermes_bundle/
├── hermes-agent/       # Git checkout or pip-installed package
├── python/             # Portable CPython (cp -RL to resolve symlinks)
├── uv                  # uv binary (optional)
└── venv/               # Pre-built virtualenv with all dependencies
```

**Build on source machine (with internet):**
```bash
# 1. Clone/checkout the application
# 2. Install uv and Python
# 3. Build venv with all deps
# 4. Copy portable Python (resolve symlinks!)
rm -rf /tmp/hermes_bundle
mkdir -p /tmp/hermes_bundle
cp -R ~/.hermes/hermes-agent/venv /tmp/hermes_bundle/venv
cp -R /tmp/hermes-agent-src /tmp/hermes_bundle/hermes-agent
cp ~/.local/bin/uv /tmp/hermes_bundle/uv
cp -RL ~/.local/share/uv/python/cpython-3.11-macos-aarch64-none /tmp/hermes_bundle/python

# 5. Create archive
tar czf /tmp/hermes_bundle.tar.gz -C /tmp hermes_bundle
```

**Transfer to target:**
```bash
# Option A: SCP (fastest, direct cable)
scp -o IdentitiesOnly=yes -i ~/.ssh/key /tmp/hermes_bundle.tar.gz admin@169.254.x.x:/tmp/

# Option B: HTTP server on source, curl on target
# On source: python3 -m http.server 8080
# On target: curl -o /tmp/bundle.tar.gz http://169.254.x.x:8080/bundle.tar.gz
```

**Install on target:**
```bash
cd /tmp && tar xzf hermes_bundle.tar.gz
mkdir -p ~/.hermes
cp -R hermes_bundle/hermes-agent ~/.hermes/

# Fix shebangs in venv bin scripts (replace source username with target path)
find hermes_bundle/venv/bin -type f | xargs sed -i '' \
  's|/Users/SOURCE_USER/.local/share/uv/python/cpython-.*|/tmp/hermes_bundle/python|g'

# Create wrapper script
cat > /usr/local/bin/hermes << 'WRAPPER'
#!/bin/bash
export PATH="/tmp/hermes_bundle/python/bin:$PATH"
exec /tmp/hermes_bundle/venv/bin/python -m hermes_cli.main "$@"
WRAPPER
chmod +x /usr/local/bin/hermes
```

**Critical: Resolve symlinks when copying Python**
`cp -L` (or `cp -RL` for directories) resolves symlinks to actual files. Without this, `python/bin/python3` may become a broken symlink pointing to a path that doesn't exist on the target machine.

See `references/offline-python-deployment.md` for full walkthrough.

### SSH Tunnel for Localhost APIs
Forward a localhost-only port from the target machine to the local machine. Useful when a service (LM Studio, web server) listens only on 127.0.0.1:

```bash
ssh -o IdentitiesOnly=yes -i ~/.ssh/key -L 1234:localhost:1234 -N user@target &
```

Now `localhost:1234` on the source machine reaches port 1234 on the target. Multiple clients can connect simultaneously — no conflict with other processes on the target using the same port directly.

### iPhone USB Tethering — Network Priority
When an iPhone is connected via USB cable for internet sharing, macOS creates an `enX` interface (e.g., `en7`) with a 172.20.10.x IP. The default route may still use WiFi — switch priority:

```bash
# Check current order
networksetup -listnetworkserviceorder | grep -E "^\\(|iPhone|Wi-Fi"

# Make iPhone USB primary (use -tt for sudo tty)
ssh -tt user@target 'echo "PASS" | sudo -S networksetup -ordernetworkservices "iPhone USB" "Wi-Fi" "Thunderbolt Bridge"'

# Verify
route -n get default | grep interface  # should show en7 (iPhone)
```

### Transfer Portable Node.js
Don't install Node.js from scratch on a restricted-internet Mac — bundle from a working Mac:

```bash
# On source: archive npm + node + core modules
cd /usr/local && tar czf /tmp/node_portable.tar.gz bin/node bin/npm bin/npx lib/node_modules

# On target via sudo -S (use -tt for pseudo-tty):
sudo tar xzf /tmp/node_portable.tar.gz -C /usr/local
```

Size: ~70 MB compressed. Node v22+ works on macOS 14+ ARM64.

### Transfer Ollama (app only, no models)
```bash
# On source: archive the .app bundle
tar czf /tmp/ollama_app.tar.gz -C /Applications Ollama.app
# Size: ~160 MB compressed

# On target: extract and symlink CLI
sudo tar xzf /tmp/ollama_app.tar.gz -C /Applications
sudo ln -sf '/Applications/Ollama.app/Contents/Resources/ollama' /usr/local/bin/ollama
```

### Claude Code — Binary Transfer
`brew install --cask claude-code` often fails on restricted internet or permission issues. Better to transfer the pre-built binary:

```bash
# Download on source (good internet):
curl -L -o /tmp/claude-darwin-arm64 \
  "https://storage.googleapis.com/claude-code-dist-86c565f3-f756-42ad-8dfa-d59b1c096819/claude-code-releases/LATEST/darwin-arm64/claude"

# SCP to target, then:
chmod +x /tmp/claude-darwin-arm64
sudo mv /tmp/claude-darwin-arm64 /usr/local/bin/claude
```

### Offline Command Line Tools Transfer
When Xcode CLT can't be downloaded (restricted internet), bundle and transfer from a machine that has them:

```bash
# On source (has CLT):
cd /Library/Developer
sudo tar czf /tmp/CLT_macOSVER.tar.gz CommandLineTools

# Transfer to target, then:
sudo tar xzf /tmp/CLT_macOSVER.tar.gz -C /Library/Developer
sudo xcode-select -s /Library/Developer/CommandLineTools
```

Size: ~2.1 GB raw, ~1.4 GB compressed. Match macOS major versions (14→14, 15→15).

### Cursor IDE — Binary Transfer
Cursor IDE (.app bundle) contains a CLI (`cursor`, `cursor-tunnel`) for headless remote development. Transfer the full app bundle — the CLI depends on Electron resources inside the .app:

```bash
# On source: archive the .app bundle (756 MB raw, ~230 MB compressed)
tar czf /tmp/cursor_app.tar.gz -C /Applications Cursor.app

# Transfer and install on target:
sudo tar xzf /tmp/cursor_app.tar.gz -C /Applications
sudo ln -sf '/Applications/Cursor.app/Contents/Resources/app/bin/cursor' /usr/local/bin/cursor
cursor --version  # verify: 3.3.x
```

### HuggingFace Model — Direct Link Extraction
Get a direct download URL for any HF model file (useful for aria2c with resume):

```bash
curl -s "https://huggingface.co/api/models/USER/REPO" | python3 -c "
import json, sys
for f in json.load(sys.stdin).get('siblings', []):
    if f['rfilename'].endswith('.gguf'):  # or .safetensors
        print(f'https://huggingface.co/USER/REPO/resolve/main/{f[\"rfilename\"]}')
"
```

### iMessage via AppleScript
On macOS, send iMessages without installing `imsg` (brew may be slow on restricted internet):

```bash
osascript -e 'tell application "Messages" to send "message text" to buddy "email@me.com" of (service 1 whose service type is iMessage)'
```

For delayed sends, use `sleep` in background:
```bash
# Background terminal: sleep 300 && osascript -e 'tell application "Messages"...'
```

## Pitfalls & Fixes

| Pitfall | Symptom | Fix |
|---|---|---|
| `sshpass` hangs or times out | Command freezes at password prompt | Switch to `expect` with `spawn ssh -tt ...` |
| "Too many authentication failures" | Server disconnects before key validation | Use `-F /dev/null -o IdentityAgent=none -o IdentitiesOnly=yes -i /path/to/key` |
| Local key has passphrase | SSH client prompts for passphrase before reaching server | Generate new key with `-N ""` or remove passphrase with `ssh-keygen -p -N "" -f key` |
| `sudo chmod -N` fails silently / needs TTY | ACL not removed, key auth still fails | Use `ssh -tt ...` to allocate pseudo-tty |
| Link-local unreachable | ping fails to 169.254.x.x | Ensure correct physical interface; 169.254.* is interface-scoped; try `.local` hostname (`admin-admin.local`) — mDNS may resolve even when raw IP doesn't |
| Editable install paths broken after transfer | `__editable___*.py` files contain absolute source paths | `sed -i '' 's|/Users/SOURCE/.hermes|/Users/TARGET/.hermes|g' venv/lib/python*/site-packages/__editable___*.py` |
| Venv Python symlink broken | `venv/bin/python` points to source machine | Recreate venv with target Python, copy site-packages |
| kimi-coding ignores config base_url | Provider hardcodes `api.moonshot.ai/v1` in `__init__.py` | Use `custom` provider or edit plugin directly — see `references/hermes-provider-quirks.md` |
| Weak local model as primary breaks fallback | Model can't self-diagnose complexity, never triggers cloud fallback | Use cloud model as primary (e.g. DeepSeek), local as fallback; or use delegation for routing |
| gemma-4 context too small | 4,096 tokens < Hermes minimum 64,000 | Use model with ≥64K context, or set `model.context_length` in config.yaml (not recommended) |
| npm global install permission denied | `EACCES` on `/usr/local/bin` | Use `sudo -S` with stored password: `echo "PASS" | sudo -S npm install -g package` |
| `brew` not found in non-interactive SSH | `zsh:1: command not found: brew` | Use full path `/opt/homebrew/bin/brew`; Homebrew isn't in the default PATH for macOS non-interactive shells |
| `brew install` hangs on \"Auto-updating\" | Appears frozen but is just slow formula update | `HOMEBREW_NO_AUTO_UPDATE=1 brew install --cask ...` skips it |
| iPhone USB has IP but no internet | `route` shows `interface: en0` (WiFi), not `en7` (iPhone) | `networksetup -ordernetworkservices "iPhone USB" "Wi-Fi"` with sudo -tt |
| Speedify Network Extension blocks Safari but not curl | Safari shows "can't establish secure connection" for ALL sites; curl and ping work fine; `systemextensionsctl list` shows Speedify.PacketTunnelSysExt as activated_enabled | Check `systemextensionsctl list` first — if a VPN/firewall network extension is active but the app is disconnected, it intercepts NSURLSession traffic (Safari, Python urllib) but NOT raw socket traffic (curl, ping). Remove the app + reboot, or disable SIP and use `systemextensionsctl uninstall`. On M1 Macs, SIP removal requires Recovery Mode. | | SSH connects from localhost but times out from remote; `lsof -i :22` shows LISTEN | `sudo networksetup -setwebproxystate Wi-Fi off` — macOS treats `Enabled: Yes` with empty `Server:` / `Port: 0` as a blocking proxy |
| Shell && kills diagnostic chains | Mid-chain command returns non-zero (e.g. `pgrep -l sshd` when sshd runs as launchd child), rest of chain doesn't run | Use `;` instead of `&&` for diagnostics — every command must run independently |
| Safari sandbox container is SIP-protected | `sudo rm -rf ~/Library/Containers/com.apple.Safari/` returns "Operation not permitted" | Safari's container cannot be reset via CLI. User must clear data via Safari GUI or create a new macOS user. |

### Fallback Does NOT Trigger on ReadTimeout

A critical gap: Hermes fallback activates on auth errors, rate limits (429), and connection errors,
but does NOT automatically trigger on `ReadTimeout`, `StreamDrop`, or `stream stale` warnings.

When the primary provider times out mid-stream (>240s of no chunks), Hermes retries the same
provider (up to `api_max_retries`) and only then checks fallback. On restricted networks, this
means the model can be stuck retrying the primary for 15+ minutes before trying fallback.

**Mitigation:**
```yaml
agent:
  api_max_retries: 1       # fewer retries → faster fallback
```
and for known-unstable connections:
```bash
hermes config set agent.api_max_retries 1
hermes config set credential_pool_strategies.kimi-coding.backoff_seconds 7200
```

But the best solution for poor connectivity is to use a cloud provider with better routing
(DeepSeek) as the primary, with the local model as fallback.

### Credential Pool Backoff
When rate-limited, force fallback and avoid retrying the primary for N seconds:
```bash
hermes config set agent.api_max_retries 1
hermes config set credential_pool_strategies.<provider>.backoff_seconds 7200  # 2 hours
```

## Reference Files
- `references/headless-mac-admin-connection.md` — Specific connection details for admin@headless-mac (IPs, key, known quirks)
- `references/offline-python-deployment.md` — Full offline Python deployment walkthrough
- `references/lm-studio-headless-deployment.md` — LM Studio CLI on headless Mac + Hermes Agent provider integration
- `references/hermes-provider-quirks.md` — Provider bugs (kimi base_url override, LM Studio setup, fallback mechanics, credential pool strategies)
- `references/ace-step-headless-deployment.md` — ACE-Step-1.5 music generation deployment plan for headless Mac behind Chinese firewall
- `references/chinese-internet-search-guide.md` — Search tools that work behind the Chinese firewall (Bing, Baidu, Gitee, ModelScope)
- `references/imessage-applescript.md` — Send iMessages via AppleScript without brew dependencies
