---
name: headless-mac-static-ip
description: Назначение статического IP на безголовом Mac в WiFi сети корабля
---

# Headless Mac Static IP

Назначение статического IP на безголовом Mac (admin, M1 Pro 32GB) через SSH.

## Когда использовать

- Нужно закрепить IP безголового Mac в текущей WiFi сети корабля
- Безголовый Mac в WiFi сети корабля (192.168.102.0/23), экранный Mac в той же сети
- После смены сети (другой корабль/отель) — нужно вернуть DHCP

## Две сети на безголовом (текущая конфигурация)

Безголовый Mac имеет два сетевых интерфейса:

| Интерфейс | Сеть | IP | Назначение |
|-----------|------|-----|------------|
| en0 (WiFi) | Корабельный WiFi (192.168.102.0/23) | **192.168.103.70** (статический) | Доступ снаружи каюты (SSH, Screen Sharing) |
| en8 (USB) | ZTE LAN (192.168.0.0/24) | **192.168.0.96** (DHCP) | Интернет через ZTE 4G/5G модем |

Default route — через ZTE (en8, 192.168.0.1). WiFi (en0) имеет флаг `I` (interface-scoped) — не используется для внешнего трафика, только для входящих подключений.

## Параметры текущей сети (корабль + ZTE)

## Параметры текущих сетей

### WiFi корабля (192.168.102.0/23)

| Параметр | Значение |
|----------|----------|
| WiFi сеть корабля | 192.168.102.0/23 |
| Маска | 255.255.254.0 |
| Шлюз | 192.168.102.1 |
| Безголовый Mac IP (статический) | 192.168.103.70 |
| Экранный Mac IP (DHCP) | 192.168.103.192 |
| DNS | 1.1.1.1, 8.8.8.8 |
| SSH ключ | ~/.ssh/id_ed25519_hermes |
| Пользователь безголового | admin |

### ZTE LAN (192.168.0.0/24)

| Параметр | Значение |
|----------|----------|
| Безголовый Mac (ZTE USB, en8, DHCP) | 192.168.0.96 |
| Шлюз ZTE | 192.168.0.1 |
| Интернет IP (ZTE, China Mobile) | 123.147.251.132 |
| WiFi SSID ZTE | см. на роутере (http://192.168.0.1) |

### ZTE 4G/5G модем (USB, 192.168.0.0/24)

| Параметр | Значение |
|----------|----------|
| Сеть ZTE | 192.168.0.0/24 |
| Безголовый (ZTE USB, en8) | 192.168.0.96 (DHCP) |
| Шлюз ZTE | 192.168.0.1 |
| Интернет через ZTE | 123.147.251.132 (China Mobile) |

## Назначить статический IP для WiFi корабля
| WiFi сеть корабля | 192.168.102.0/23, шлюз 192.168.102.1 |

## SOCKS5 туннель для интернета

Если безголовому Mac нужен интернет через экранный Mac (iPhone USB):

```bash
# Одноразово: добавить ключ безголового в authorized_keys экранного
ssh -i ~/.ssh/id_ed25519_hermes admin@192.168.103.70 \
  "cat ~/.ssh/id_ed25519_hermes.pub" >> ~/.ssh/authorized_keys

# Запуск туннеля (на безголовом создаётся SOCKS5 на :1080)
ssh -i ~/.ssh/id_ed25519_hermes admin@192.168.103.70 \
  "ssh -i ~/.ssh/id_ed25519_hermes -D 1080 -N -f \
     jenyanovak@192.168.103.192 && echo 'SOCKS UP'"

# Использование
ssh -i ~/.ssh/id_ed25519_hermes admin@192.168.103.70 \
  "ALL_PROXY=socks5h://127.0.0.1:1080 \
   hermes chat -q 'привет'"
```

Детали: china-networking skill → "SOCKS5 SSH Tunnel Over WiFi".
## Назначить статический IP

```bash
ssh -i ~/.ssh/id_ed25519_hermes admin@192.168.103.70 \
  "sudo networksetup -setmanual 'Wi-Fi' 192.168.103.70 255.255.254.0 192.168.102.1 && \
   sudo networksetup -setdnsservers 'Wi-Fi' 1.1.1.1 8.8.8.8"
```

## Проверить

```bash
ssh -i ~/.ssh/id_ed25519_hermes admin@192.168.103.70 \
  "networksetup -getinfo Wi-Fi; echo '==='; networksetup -getdnsservers Wi-Fi"
```

Ожидаемый вывод:
```
Manual Configuration
IP address: 192.168.103.70
Subnet mask: 255.255.254.0
Router: 192.168.102.1
IPv6: Off
Wi-Fi ID: bc:d0:74:46:20:0e
===
1.1.1.1
8.8.8.8
```

## Вернуть DHCP (при смене сети)

```bash
ssh -i ~/.ssh/id_ed25519_hermes admin@<текущий_IP_безголового> \
  "sudo networksetup -setdhcp 'Wi-Fi'; \
   sudo networksetup -setdnsservers 'Wi-Fi' empty"
```

## Важно

- Пароль sudo на безголовом Mac не требуется через SSH (sudo настроен без пароля)
- Если IP безголового Mac изменился после смены сети — найти через mDNS: `dns-sd -G v4 admin.local` или `arp -a | grep bc:d0:74:46:20:0e`
- Экранный Mac остаётся на DHCP — его IP не фиксирован
- Интернет на экранном Mac идёт через iPhone USB (en5), не через WiFi корабля

## Статический IP — ТОЛЬКО для сети корабля

Статический IP `192.168.103.70` назначен на **WiFi интерфейс корабля** (подсеть 192.168.102.0/23). 
Он **не относится** к другим сетям:

| Сеть | IP безголового | Назначение |
|------|---------------|------------|
| WiFi корабля (192.168.102.0/23) | 192.168.103.70 ✅ статика | SSH/Screen Sharing |
| ZTE 4G (192.168.0.0/24) | 192.168.0.96 (DHCP) | Интернет через USB |
| iPhone USB (172.20.10.0/28) | 172.20.10.4 (DHCP) | Интернет через iPhone |

**Когда безголовый в ZTE сети (каюта):** не трогай WiFi-статику. WiFi корабля остаётся на `192.168.103.70` (если он ещё в зоне), а ZTE даёт свой IP через DHCP.

**При смене WiFi сети** (другой корабль/отель) — нужно вернуть DHCP на WiFi интерфейс:
```bash
ssh -i ~/.ssh/id_ed25519_hermes admin@<текущий_IP_безголового> \
  "sudo networksetup -setdhcp 'Wi-Fi' && \
   sudo networksetup -setdnsservers 'Wi-Fi' empty"
```

## macOS 15 TCC — ограничения SSH

На macOS 15 (Sequoia) TCC может блокировать SSH-доступ к пользовательским файлам:

- `ls /Users/admin/Downloads/` → "Operation not permitted" даже от sudo
- `cat ~/Downloads/qwen3-models/` → та же ошибка
- Это НЕ ошибка — это TCC защита на уровне APFS. Решение: или дать Full Disk Access для sshd через GUI System Settings, или обходить через launchctl asuser, или просто не пытаться читать TCC-защищённые пути через SSH

**Для доступа к файлам в Downloads:** переместить файлы в `/tmp/` или `/Users/admin/` напрямую (минуя Downloads)

## SSH соединение (для справки)

```bash
ssh -i ~/.ssh/id_ed25519_hermes admin@192.168.103.70
```

## Cross-references

- Замер скорости WiFi между Mac: `wifi-speed-test-headless-mac` skill
- Интернет через iPhone USB: `iphone-cable-internet` skill
- Раздача интернета между Mac (оба направления): `ship-wifi-iphone-sharing` skill
- WiFi сеть корабля — раздел в `ship-wifi-iphone-sharing`
