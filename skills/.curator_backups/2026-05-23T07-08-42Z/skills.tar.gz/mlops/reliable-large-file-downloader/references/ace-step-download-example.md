# ACE-Step Model Download — Session Notes

## Context
- Machine: M1 Pro Mac (21.3GB unified), headless, China network (iPhone tethering en7)
- Project: ACE-Step-1.5 (AI music generation)
- Repo: https://github.com/ace-step/ACE-Step-1.5 cloned to /tmp/ace-step
- Models needed from `ACE-Step/Ace-Step1.5`:
  - acestep-v15-turbo/model.safetensors (~2.3GB expected, HF-Mirror version 4.4GB)
  - acestep-5Hz-lm-1.7B/model.safetensors (~2.6GB expected, HF-Mirror version 4.4GB)
  - vae/diffusion_pytorch_model.safetensors (322MB)
  - Qwen3-Embedding-0.6B/model.safetensors (1.1GB)

## Speed Test Results (May 12, 2026, iPhone tethering)
| Source | Single-stream | 4-stream (aria2c) |
|--------|--------------|-------------------|
| HF-Mirror | ~360 KB/s | ~900 KB/s |
| ModelScope | ~8 KB/s | dead |

HF-Mirror was 45× faster than ModelScope for this session.

## Key Learnings

### 1. ModelScope `._____temp` corruption pattern
ModelScope's `snapshot_download` may download `.safetensors` files into a hidden `._____temp/` directory instead of the target. Files can be complete but misplaced, or partial (corrupted). After finding files in `._____temp/`:
- Move them to target dirs
- **MUST verify** with `safetensors.safe_open()` — file existence ≠ validity

### 2. Safetensors Integrity Verification
Error signature of corrupted file:
```
safetensors_rust.SafetensorError: Error while deserializing header: incomplete metadata, file not fully covered
```
This means the file was a partial download whose metadata header never completed. Fix: delete file, re-download with `--force` or resume with aria2c `-c`.

Valid check: `safetensors.safe_open(path, framework='pt')` — both ACE-Step models had 677 keys when valid.

### 3. ACE-Step model_downloader quirks
- `--prefer-source` is NOT a valid CLI flag — use env var `ACESTEP_DOWNLOAD_SOURCE=modelscope`
- `--force` works for re-download but uses `snapshot_download` (entire repo, slow)
- Better: download individual `.safetensors` files via aria2c from HF-Mirror
- `_contains_model_weights()` only checks file existence, not integrity
- Model code sync happens at startup (auto-copies .py files from acestep/models/ to checkpoints)

### 4. HF-Mirror direct URLs
Pattern: `https://hf-mirror.com/{org}/{repo}/resolve/main/{path}`
Example: `https://hf-mirror.com/ACE-Step/Ace-Step1.5/resolve/main/acestep-v15-turbo/model.safetensors`

### 5. aria2c command for ACE-Step (multi-file, resumable)
```bash
cd /tmp/ace-step/checkpoints && aria2c \
  --check-certificate=false \
  -x 4 -s 4 -c \
  --max-connection-per-server=4 \
  --max-tries=10 --retry-wait=15 \
  -d acestep-v15-turbo -o model.safetensors \
  "https://hf-mirror.com/ACE-Step/Ace-Step1.5/resolve/main/acestep-v15-turbo/model.safetensors" \
  -d acestep-5Hz-lm-1.7B -o model.safetensors \
  "https://hf-mirror.com/ACE-Step/Ace-Step1.5/resolve/main/acestep-5Hz-lm-1.7B/model.safetensors"
```
DNS failures (exit code 19, `Could not contact DNS servers`) preserve partial progress via `.aria2` control files — just restart the same command.

### 6. Cronjob Watchdog Pattern
Used cronjob with `schedule: "0,30 * * * *"` (every 30 min at :00/:30), `deliver: "origin"`.
Prompt checks: process alive, file sizes, .aria2 files, safetensors integrity.
When done: starts API server and generates test track.

### 7. FFmpeg Required for Audio Output
ACE-Step saves generated audio via torchcodec which needs FFmpeg shared libraries.
Error: `OSError: Could not load this library: libtorchcodec_core*.dylib → Library not loaded: @rpath/libavutil.*.dylib`
Fix: `brew install ffmpeg` then restart the server process.

### 8. MLX Fallback to PyTorch/MPS
When MLX backend can't load the LM model (architecture mismatch — "Received 677 parameters not in model"), ACE-Step automatically falls back to PyTorch backend on MPS. This is expected behavior and generation still works with GPU acceleration.

### 9. Server Launch Commands
```bash
# API server (REST, Swagger at /docs)
cd /tmp/ace-step && \
  ACESTEP_LM_BACKEND=mlx ACESTEP_NO_INIT=false \
  .venv/bin/python -m uvicorn acestep.api_server:app \
  --host 0.0.0.0 --port 8001 --workers 1

# Gradio Web UI (browser interface at :7860)
cd /tmp/ace-step && \
  ACESTEP_LM_BACKEND=mlx \
  .venv/bin/python -c "
import sys
sys.argv = ['acestep', '--port', '7860', '--server-name', '0.0.0.0']
from acestep.acestep_v15_pipeline import main
main()
"
# Note: Use 0.0.0.0 (not 127.0.0.1) for access from other devices on the network.
# The Gradio UI is launched via the 'acestep' CLI entry point, not a separate module.

# Health check
curl http://127.0.0.1:8001/health

# Generate task
curl -X POST http://127.0.0.1:8001/release_task \
  -H "Content-Type: application/json" \
  -d '{"prompt":"calm piano melody","duration":8}'

# Query result
curl -X POST http://127.0.0.1:8001/query_result \
  -H "Content-Type: application/json" \
  -d '{"task_id":"<id>"}'
```
